#!/bin/bash
echo "Make cleaning both directories"
make clean
cd Benchmark
make clean
cd ..
