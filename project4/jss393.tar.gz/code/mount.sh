#!/bin/sh
 ./tfs -s /tmp/jss393/mountdir
 echo Mounted /tmp/jss393/mountdir

