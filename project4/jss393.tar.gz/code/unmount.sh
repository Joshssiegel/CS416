#!/bin/sh
fusermount -u /tmp/jss393/mountdir 
 echo unmounted /tmp/jss393/mountdir

