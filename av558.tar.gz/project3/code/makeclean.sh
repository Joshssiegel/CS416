#!/bin/bash
echo "Make cleaning both directories"
make clean
cd benchmark
make clean
cd ..
